import "./bubble-chart.css";

const BubbleChart = () => {
  return (
    <div className="bubble-chart">
      <div className="background" />
      <div className="big-widget-bubble-chart">
        <img className="bg-lines-icon" alt="" src="../bg-lines.svg" />
        <img className="bg-lines-icon1" alt="" src="../bg-lines1.svg" />
        <img className="bubble-chart-icon" alt="" src="../bubble-chart.svg" />
        <div className="investments">
          <div className="time">3 month</div>
          <div className="tittle">Investments</div>
          <div className="value">$76,644</div>
        </div>
        <div className="design">
          <div className="time1">3 month</div>
          <div className="value1">$32,982</div>
          <div className="title">Design</div>
        </div>
        <div className="finance">
          <div className="value2">
            <span> $</span>
            <span className="span">23,657</span>
          </div>
          <div className="title1">Finance</div>
        </div>
        <div className="business">
          <div className="value3">$21,987</div>
          <div className="title2">Business</div>
        </div>
        <div className="development">
          <div className="value4">$31,657</div>
          <div className="title3">Development</div>
        </div>
      </div>
      <div className="title4">Design faster</div>
      <img className="bubble-icon" alt="" src="../bubble.svg" />
      <img className="bubble-icon1" alt="" src="../bubble1.svg" />
      <img className="bubble-icon2" alt="" src="../bubble2.svg" />
      <img className="bubble-icon3" alt="" src="../bubble3.svg" />
      <img className="bubble-icon4" alt="" src="../bubble4.svg" />
      <b className="timeline">Timeline</b>
      <div className="timeline1">
        <div className="background-element" />
        <div className="date-range-picker">
          <div className="time-period">
            <div className="period">1W</div>
          </div>
          <div className="time-period">
            <div className="period">1M</div>
          </div>
          <div className="time-period2">
            <div className="hover" />
            <b className="period2">3M</b>
          </div>
          <div className="time-period">
            <div className="period">1Y</div>
          </div>
          <div className="time-period">
            <div className="period">ALL</div>
          </div>
        </div>
      </div>
      <div className="navigation-bar">
        <div className="bg" />
        <div className="search">
          <div className="input" />
          <img className="icon" alt="" src="../icon.svg" />
        </div>
        <div className="tab" />
        <div className="menu">
          <div className="label">Statistics</div>
          <div className="label1">Overview</div>
          <div className="label">Dashboard</div>
          <div className="label">Analytics</div>
        </div>
        <img className="profile-icon" alt="" src="../profile.svg" />
        <img className="option-icon" alt="" src="../option.svg" />
        <div className="logo">
          <img className="logo-icon" alt="" src="../logo.svg" />
          <div className="orion">ORION</div>
        </div>
      </div>
      <div className="footer">
        <div className="bg" />
        <b className="orion-data-visualisation">Orion data visualisation</b>
        <b className="b">2022</b>
      </div>
      <div className="informer-trend-goods">
        <div className="value5">204</div>
        <b className="title5">Trend goods</b>
        <img className="icon1" alt="" src="../icon1.svg" />
      </div>
      <div className="informer-trend-goods1">
        <div className="value6">65,540</div>
        <b className="title6">Shopping views</b>
        <img className="icon1" alt="" src="../icon2.svg" />
      </div>
      <div className="informer-trend-goods2">
        <div className="value7">324</div>
        <b className="title7">Store dynamics</b>
        <img className="icon1" alt="" src="../icon3.svg" />
      </div>
      <img className="panel-group-icon" alt="" src="../panel-group.svg" />
      <div className="widget-m-size-combined-cir">
        <div className="graph">
          <img
            className="chart-double-big-circle-char"
            alt=""
            src="../chart--double-big-circle-chart.svg"
          />
          <div className="info">
            <div className="title8">
              <div className="name">Total earning</div>
            </div>
            <div className="value8">
              <div className="amount">$12,875</div>
              <div className="indicator">
                <img className="arrow-up-icon" alt="" src="../arrow-up.svg" />
                <div className="percent">2%</div>
              </div>
            </div>
            <div className="detail">Compared to $21,504 last year</div>
          </div>
        </div>
        <div className="table">
          <div className="row">
            <div className="name1">Presentation</div>
            <div className="amount1">862</div>
            <div className="graph1">
              <div className="column" />
              <div className="column1" />
              <div className="column2" />
              <div className="column3" />
              <img className="chart-icon" alt="" src="../chart.svg" />
            </div>
          </div>
          <div className="row">
            <div className="name1">Development</div>
            <div className="amount1">753</div>
            <div className="graph1">
              <div className="column" />
              <div className="column1" />
              <div className="column2" />
              <div className="column3" />
              <img className="chart-icon1" alt="" src="../chart1.svg" />
            </div>
          </div>
          <div className="row">
            <div className="name1">Research</div>
            <div className="amount1">553</div>
            <div className="graph1">
              <div className="column" />
              <div className="column1" />
              <div className="column2" />
              <div className="column3" />
              <img className="chart-icon2" alt="" src="../chart2.svg" />
            </div>
          </div>
        </div>
      </div>
      <div className="widget-m-size-omposite-in">
        <div className="informer">
          <div className="title9">
            <div className="name4">Total earning</div>
          </div>
          <div className="value9">
            <div className="amount4">$12,875</div>
            <div className="indicator1">
              <img className="arrow-up-icon" alt="" src="../arrow-up1.svg" />
              <div className="percent1">10%</div>
            </div>
          </div>
          <div className="detail1">Compared to $21,490 last year</div>
        </div>
        <img className="divider-icon" alt="" src="../divider.svg" />
        <div className="informer">
          <div className="title9">
            <div className="name4">Sales</div>
          </div>
          <div className="value9">
            <div className="amount4">$43,123</div>
            <div className="indicator1">
              <img className="arrow-up-icon" alt="" src="../arrow-up1.svg" />
              <div className="percent1">12%</div>
            </div>
          </div>
          <div className="detail1">Compared to $21,490 last year</div>
        </div>
      </div>
      <div className="table-indicator-table">
        <div className="summary">
          <div className="summary">
            <div className="name6">Travel</div>
            <div className="amount6">760</div>
            <div className="summary1">2,540</div>
          </div>
          <div className="status">
            <img className="arrow-up-icon" alt="" src="../arrow-up3.svg" />
            <img className="arrow-up-icon4" alt="" src="../arrow-up4.svg" />
          </div>
        </div>
        <div className="summary">
          <div className="summary">
            <div className="name6">Presentation</div>
            <div className="amount6">650</div>
            <div className="summary1">2,304</div>
          </div>
          <div className="status">
            <img className="arrow-up-icon4" alt="" src="../arrow-up3.svg" />
            <img className="arrow-up-icon" alt="" src="../arrow-up4.svg" />
          </div>
        </div>
        <div className="summary">
          <div className="summary">
            <div className="name6">Business</div>
            <div className="amount6">612</div>
            <div className="summary1">2,140</div>
          </div>
          <div className="status">
            <img className="arrow-up-icon" alt="" src="../arrow-up3.svg" />
            <img className="arrow-up-icon4" alt="" src="../arrow-up4.svg" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default BubbleChart;
