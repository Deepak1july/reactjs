import "./world-hexagon-map.css";

const WorldHexagonMap = () => {
  return (
    <div className="world-hexagon-map">
      <div className="widget-l-size-timeline-cha">
        <div className="info1">
          <div className="value11">
            <div className="value12">
              <div className="title11">Sales Figures</div>
              <div className="value13">$10,430</div>
            </div>
          </div>
        </div>
        <div className="graph4">
          <div className="chart">
            <div className="column12" />
            <div className="column13" />
            <div className="column14" />
            <div className="column15" />
            <div className="column16" />
            <div className="column17" />
            <div className="column16" />
            <div className="column19" />
            <div className="column20" />
            <div className="column15" />
            <div className="column15" />
            <div className="column19" />
            <div className="column15" />
            <div className="column25" />
            <div className="column26" />
            <div className="column27" />
            <div className="column28" />
            <div className="column26" />
            <div className="column30" />
            <div className="column31" />
            <div className="column32" />
            <div className="column33" />
            <div className="column34" />
            <div className="column35" />
            <div className="column36" />
            <div className="column30" />
            <div className="column38" />
            <div className="column38" />
            <div className="column40" />
            <div className="column38" />
            <div className="column28" />
            <div className="column43" />
            <div className="column26" />
            <div className="column26" />
            <div className="column28" />
            <div className="column26" />
            <div className="column25" />
            <div className="column26" />
            <div className="column27" />
            <div className="column28" />
            <div className="column26" />
            <div className="column26" />
            <div className="column54" />
            <div className="column43" />
            <div className="column27" />
            <div className="column27" />
            <div className="column12" />
            <div className="column13" />
            <div className="column14" />
            <div className="column15" />
            <div className="column62" />
            <div className="column62" />
            <div className="column64" />
            <div className="column62" />
            <div className="column66" />
            <div className="column67" />
            <div className="column27" />
            <div className="column27" />
            <div className="column66" />
            <div className="column27" />
            <div className="column72" />
            <div className="column27" />
            <div className="column25" />
            <div className="column66" />
            <div className="column66" />
            <div className="column66" />
            <div className="column66" />
            <div className="column27" />
            <div className="column80" />
            <div className="column80" />
            <div className="column82" />
            <div className="column83" />
          </div>
          <div className="line">
            <div className="bg1" />
            <div className="cian" />
            <div className="yellow" />
          </div>
        </div>
      </div>
      <div className="navigation-bar1">
        <div className="background2" />
        <div className="search1">
          <div className="input1" />
          <img className="icon4" alt="" src="../icon.svg" />
        </div>
        <div className="tab1" />
        <div className="menu1">
          <div className="label4">Statistics</div>
          <div className="label5">Overview</div>
          <div className="label4">Dashboard</div>
          <div className="label4">Analytics</div>
        </div>
        <img className="profile-icon1" alt="" src="../profile.svg" />
        <img className="option-icon1" alt="" src="../option.svg" />
        <div className="logo1">
          <img className="logo-icon1" alt="" src="../logo1.svg" />
          <div className="name9">ORION</div>
        </div>
      </div>
      <div className="footer1">
        <div className="background2" />
        <b className="description">Orion data visualisation</b>
        <b className="b1">2019</b>
      </div>
      <div className="side-indicators">
        <div className="informer-info-with-icon">
          <img className="icon5" alt="" src="../icon5.svg" />
          <div className="info2">
            <div className="title12">Total earning</div>
            <div className="amount9">
              <div className="value14">540,549</div>
              <div className="indicator3">
                <img className="up-icon" alt="" src="../up.svg" />
                <div className="div">145</div>
              </div>
            </div>
          </div>
        </div>
        <div className="informer-info-with-icon">
          <img className="icon5" alt="" src="../icon6.svg" />
          <div className="info2">
            <div className="title12">Sales</div>
            <div className="amount9">
              <div className="value14">1,205,677</div>
              <div className="indicator3">
                <img className="up-icon" alt="" src="../up.svg" />
                <div className="div">145</div>
              </div>
            </div>
          </div>
        </div>
        <div className="informer-info-with-icon">
          <img className="icon5" alt="" src="../icon7.svg" />
          <div className="info2">
            <div className="title12">Purchase</div>
            <div className="amount9">
              <div className="value14">48,430,039</div>
              <div className="indicator3">
                <img className="up-icon" alt="" src="../up.svg" />
                <div className="div">145</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="widget-m-size-big-circle-c">
        <div className="chart1">
          <div className="percent3">
            <span className="span1">27</span>%
          </div>
          <img className="background-icon" alt="" src="../background.svg" />
          <img className="progress-icon" alt="" src="../progress.svg" />
        </div>
        <div className="info5">
          <div className="amount12">92,980</div>
          <div className="detail3">Active users</div>
        </div>
      </div>
      <div className="widget-m-size-big-circle-c1">
        <div className="chart1">
          <div className="percent3">
            <span className="span1">67</span>%
          </div>
          <img className="background-icon" alt="" src="../background.svg" />
          <img className="progress-icon1" alt="" src="../progress1.svg" />
        </div>
        <div className="info5">
          <div className="amount12">22,652</div>
          <div className="detail3">New users</div>
        </div>
      </div>
      <img className="hex-map-icon" alt="" src="../hex-map.svg" />
      <div className="map-pin-pin-with-name">
        <div className="tooltip">
          <img className="indicator-icon" alt="" src="../indicator.svg" />
          <div className="info2">
            <div className="title15">Chicago</div>
            <div className="amount14">98,320,300</div>
          </div>
        </div>
        <img className="arrow-icon" alt="" src="../arrow.svg" />
      </div>
      <div className="map-pin-pin-with-name1">
        <div className="tooltip">
          <img className="indicator-icon" alt="" src="../indicator1.svg" />
          <div className="info2">
            <div className="title15">Manaus</div>
            <div className="amount14">12,320,300</div>
          </div>
        </div>
        <img className="arrow-icon" alt="" src="../arrow.svg" />
      </div>
      <div className="map-pin-pin-with-name2">
        <div className="tooltip">
          <img className="indicator-icon" alt="" src="../indicator2.svg" />
          <div className="info2">
            <div className="title15">Berlin</div>
            <div className="amount14">76,541,106</div>
          </div>
        </div>
        <img className="arrow-icon" alt="" src="../arrow.svg" />
      </div>
      <div className="map-pin-pin-with-name3">
        <div className="tooltip">
          <img className="indicator-icon" alt="" src="../indicator3.svg" />
          <div className="info2">
            <div className="title15">Giza</div>
            <div className="amount14">10,547,980</div>
          </div>
        </div>
        <img className="arrow-icon" alt="" src="../arrow.svg" />
      </div>
      <div className="map-pin-pin-with-name4">
        <div className="tooltip">
          <img className="indicator-icon" alt="" src="../indicator4.svg" />
          <div className="info2">
            <div className="title15">Shanghai</div>
            <div className="amount14">239,570,110</div>
          </div>
        </div>
        <img className="arrow-icon" alt="" src="../arrow.svg" />
      </div>
      <div className="map-pin-pin-with-name5">
        <div className="tooltip">
          <img className="indicator-icon" alt="" src="../indicator5.svg" />
          <div className="info2">
            <div className="title15">Queensland</div>
            <div className="amount14">6,097,321</div>
          </div>
        </div>
        <img className="arrow-icon" alt="" src="../arrow.svg" />
      </div>
      <div className="footer1">
        <div className="background2" />
        <b className="description">Orion data visualisation</b>
        <b className="b1">2022</b>
      </div>
      <div className="amount20">2,431,340</div>
      <div className="title21">
        <div className="value14">All users</div>
        <div className="detail5">
          <b className="detail6">Detail</b>
          <img className="arow-icon" alt="" src="../arow.svg" />
        </div>
      </div>
      <div className="widget-l-size-global-stati">
        <div className="header">
          <div className="title22">Sales Figures</div>
          <div className="legend">
            <div className="shape" />
            <div className="marketing-sales">Sales</div>
          </div>
          <div className="legend">
            <div className="shape1" />
            <div className="marketing-sales">Users</div>
          </div>
          <div className="legend">
            <div className="shape2" />
            <div className="marketing-sales">Product</div>
          </div>
          <div className="legend">
            <div className="shape3" />
            <div className="marketing-sales">Team</div>
          </div>
        </div>
        <div className="graph5">
          <div className="chart3">
            <div className="y-axis">
              <div className="k">1k</div>
              <div className="div3">0</div>
              <div className="div4">200</div>
              <div className="div5">400</div>
              <div className="div6">600</div>
              <div className="div7">800</div>
            </div>
            <div className="x-axis">
              <div className="dec">
                <div className="name11">Dec</div>
                <img className="shape-icon" alt="" src="../shape.svg" />
              </div>
              <div className="nov">
                <div className="name12">Nov</div>
                <img className="shape-icon" alt="" src="../shape1.svg" />
              </div>
              <div className="oct">
                <div className="name13">Oct</div>
                <img className="shape-icon2" alt="" src="../shape2.svg" />
              </div>
              <div className="sep">
                <div className="name14">Sep</div>
                <img className="shape-icon3" alt="" src="../shape3.svg" />
              </div>
              <div className="aug">
                <div className="name15">Aug</div>
                <img className="shape-icon" alt="" src="../shape4.svg" />
              </div>
              <div className="jul">
                <div className="name16">Jul</div>
                <img className="shape-icon5" alt="" src="../shape5.svg" />
              </div>
              <div className="jun">
                <div className="name17">Jun</div>
                <img className="shape-icon6" alt="" src="../shape6.svg" />
              </div>
              <div className="may">
                <div className="name18">May</div>
                <img className="shape-icon7" alt="" src="../shape7.svg" />
              </div>
              <div className="apr">
                <div className="name19">Apr</div>
                <img className="shape-icon8" alt="" src="../shape8.svg" />
              </div>
              <div className="mar">
                <div className="name20">Mar</div>
                <img className="shape-icon9" alt="" src="../shape9.svg" />
              </div>
              <div className="feb">
                <div className="name21">Feb</div>
                <img className="shape-icon10" alt="" src="../shape10.svg" />
              </div>
              <div className="jan">
                <div className="name21">Jan</div>
                <img className="shape-icon11" alt="" src="../shape11.svg" />
              </div>
            </div>
          </div>
          <div className="data">
            <img className="bubble-icon5" alt="" src="../bubble5.svg" />
            <img className="bubble-icon6" alt="" src="../bubble6.svg" />
            <img className="bubble-icon7" alt="" src="../bubble7.svg" />
            <img className="bubble-icon8" alt="" src="../bubble8.svg" />
            <img className="bubble-icon9" alt="" src="../bubble9.svg" />
            <img className="bubble-icon10" alt="" src="../bubble10.svg" />
            <img className="bubble-icon11" alt="" src="../bubble11.svg" />
            <img className="bubble-icon12" alt="" src="../bubble12.svg" />
            <img className="bubble-icon13" alt="" src="../bubble13.svg" />
            <img className="bubble-icon14" alt="" src="../bubble14.svg" />
            <img className="bubble-icon15" alt="" src="../bubble15.svg" />
            <div className="bubble">
              <img className="bubble-icon16" alt="" src="../bubble16.svg" />
              <div className="value17">$27632</div>
            </div>
            <div className="bubble1">
              <img className="bubble-icon17" alt="" src="../bubble17.svg" />
              <div className="value18">$27632</div>
            </div>
            <div className="bubble2">
              <img className="bubble-icon18" alt="" src="../bubble18.svg" />
              <div className="value19">$27632</div>
              <div className="text">August</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorldHexagonMap;
