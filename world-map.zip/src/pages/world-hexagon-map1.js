import "bootstrap/dist/css/bootstrap.min.css";
import { TextField } from "@mui/material";
import { Form } from "react-bootstrap";
import "./world-hexagon-map1.css";

const WorldHexagonMap1 = () => {
  return (
    <div className="world-hexagon-map1">
      <div className="widget-l-size-timeline-cha1">
        <div className="info13">
          <div className="value20">
            <div className="value21">
              <div className="title23">Sales Figures</div>
              <div className="value22">$10,430</div>
            </div>
          </div>
        </div>
        <div className="graph6">
          <div className="chart4">
            <div className="column84" />
            <div className="column85" />
            <div className="column86" />
            <div className="column87" />
            <div className="column88" />
            <div className="column89" />
            <div className="column88" />
            <div className="column91" />
            <div className="column92" />
            <div className="column92" />
            <div className="column87" />
            <div className="column87" />
            <div className="column91" />
            <div className="column87" />
            <div className="column98" />
            <div className="column99" />
            <div className="column100" />
            <div className="column101" />
            <div className="column99" />
            <div className="column103" />
            <div className="column104" />
            <div className="column105" />
            <div className="column106" />
            <div className="column107" />
            <div className="column108" />
            <div className="column109" />
            <div className="column103" />
            <div className="column111" />
            <div className="column111" />
            <div className="column113" />
            <div className="column111" />
            <div className="column101" />
            <div className="column116" />
            <div className="column99" />
            <div className="column99" />
            <div className="column101" />
            <div className="column99" />
            <div className="column98" />
            <div className="column99" />
            <div className="column100" />
            <div className="column101" />
            <div className="column99" />
            <div className="column99" />
            <div className="column127" />
            <div className="column116" />
            <div className="column100" />
            <div className="column100" />
            <div className="column84" />
            <div className="column85" />
            <div className="column86" />
            <div className="column87" />
            <div className="column135" />
            <div className="column135" />
            <div className="column137" />
            <div className="column135" />
            <div className="column139" />
            <div className="column140" />
            <div className="column100" />
            <div className="column100" />
            <div className="column139" />
            <div className="column100" />
            <div className="column145" />
            <div className="column100" />
            <div className="column98" />
            <div className="column139" />
            <div className="column139" />
            <div className="column139" />
            <div className="column139" />
            <div className="column100" />
            <div className="column153" />
            <div className="column153" />
            <div className="column155" />
            <div className="column156" />
          </div>
          <div className="line1">
            <div className="bg4" />
            <div className="cian1" />
            <div className="yellow1" />
          </div>
        </div>
      </div>
      <div className="navigation-bar2">
        <div className="background3" />
        <div className="search2">
          <div className="input2" />
          <img className="icon8" alt="" src="../icon8.svg" />
        </div>
        <div className="tab2" />
        <div className="menu2">
          <div className="label8">Statistics</div>
          <div className="label9">Overview</div>
          <div className="label8">Dashboard</div>
          <div className="label8">Analytics</div>
        </div>
        <img className="profile-icon2" alt="" src="../profile2.svg" />
        <img className="option-icon2" alt="" src="../option2.svg" />
        <div className="logo2">
          <img className="logo-icon2" alt="" src="../logo2.svg" />
          <div className="name23">ORION</div>
        </div>
      </div>
      <div className="footer3">
        <div className="background3" />
        <b className="orion-data-visualisation2">Orion data visualisation</b>
        <b className="b3">2019</b>
      </div>
      <div className="side-indicators1">
        <div className="informer-info-with-icon3">
          <img className="icon9" alt="" src="../icon9.svg" />
          <div className="info14">
            <div className="title24">Total earning</div>
            <div className="amount21">
              <div className="value23">540,549</div>
              <div className="indicator6">
                <img className="up-icon3" alt="" src="../up.svg" />
                <div className="div8">145</div>
              </div>
            </div>
          </div>
        </div>
        <div className="informer-info-with-icon3">
          <img className="icon9" alt="" src="../icon6.svg" />
          <div className="info14">
            <div className="title24">Sales</div>
            <div className="amount21">
              <div className="value23">1,205,677</div>
              <div className="indicator6">
                <img className="up-icon3" alt="" src="../up.svg" />
                <div className="div8">145</div>
              </div>
            </div>
          </div>
        </div>
        <div className="informer-info-with-icon3">
          <img className="icon9" alt="" src="../icon7.svg" />
          <div className="info14">
            <div className="title24">Purchase</div>
            <div className="amount21">
              <div className="value23">48,430,039</div>
              <div className="indicator6">
                <img className="up-icon3" alt="" src="../up.svg" />
                <div className="div8">145</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="widget-m-size-big-circle-c2">
        <div className="chart5">
          <div className="percent5">
            <span className="span3">27</span>%
          </div>
          <img className="background-icon2" alt="" src="../background.svg" />
          <img className="progress-icon2" alt="" src="../progress.svg" />
        </div>
        <div className="info17">
          <div className="amount24">92,980</div>
          <div className="detail7">Active users</div>
        </div>
      </div>
      <div className="widget-m-size-big-circle-c3">
        <div className="chart5">
          <div className="percent5">
            <span className="span3">67</span>%
          </div>
          <img className="background-icon2" alt="" src="../background.svg" />
          <img className="progress-icon3" alt="" src="../progress1.svg" />
        </div>
        <div className="info17">
          <div className="amount24">22,652</div>
          <div className="detail7">New users</div>
        </div>
      </div>
      <img className="hex-map-icon1" alt="" src="../hex-map1.svg" />
      <div className="map-pin-pin-with-name6">
        <div className="tooltip6">
          <img className="indicator-icon6" alt="" src="../indicator6.svg" />
          <div className="info14">
            <div className="title27">Chicago</div>
            <div className="amount26">98,320,300</div>
          </div>
        </div>
        <img className="arrow-icon6" alt="" src="../arrow.svg" />
      </div>
      <div className="map-pin-pin-with-name7">
        <div className="tooltip6">
          <img className="indicator-icon6" alt="" />
          <div className="info14">
            <div className="title27">Manaus</div>
            <div className="amount26">12,320,300</div>
          </div>
        </div>
        <img className="arrow-icon6" alt="" />
      </div>
      <div className="map-pin-pin-with-name8">
        <div className="tooltip6">
          <img className="indicator-icon6" alt="" src="../indicator7.svg" />
          <div className="info14">
            <div className="title27">Berlin</div>
            <div className="amount26">76,541,106</div>
          </div>
        </div>
        <img className="arrow-icon6" alt="" src="../arrow.svg" />
      </div>
      <div className="map-pin-pin-with-name9">
        <div className="tooltip6">
          <img className="indicator-icon6" alt="" src="../indicator8.svg" />
          <div className="info14">
            <div className="title27">Giza</div>
            <div className="amount26">10,547,980</div>
          </div>
        </div>
        <img className="arrow-icon6" alt="" src="../arrow.svg" />
      </div>
      <div className="map-pin-pin-with-name10">
        <div className="tooltip6">
          <img className="indicator-icon6" alt="" src="../indicator9.svg" />
          <div className="info14">
            <div className="title27">Shanghai</div>
            <div className="amount26">239,570,110</div>
          </div>
        </div>
        <img className="arrow-icon6" alt="" src="../arrow.svg" />
      </div>
      <div className="map-pin-pin-with-name11">
        <div className="tooltip6">
          <img className="indicator-icon6" alt="" src="../indicator10.svg" />
          <div className="info14">
            <div className="title27">Queensland</div>
            <div className="amount26">6,097,321</div>
          </div>
        </div>
        <img className="arrow-icon6" alt="" src="../arrow.svg" />
      </div>
      <div className="footer3">
        <div className="background3" />
        <b className="orion-data-visualisation2">Orion data visualisation</b>
        <b className="b3">2022</b>
      </div>
      <div className="amount32">2,431,340</div>
      <TextField
        className="title33"
        color="primary"
        variant="filled"
        defaultValue="Detail"
        type="text"
        label="All users"
        placeholder="Placeholder"
        size="medium"
        margin="none"
      />
      <Form.Group className="inputstandard-formgroup">
        <Form.Control type="text" placeholder="Input placeholder" />
      </Form.Group>
    </div>
  );
};

export default WorldHexagonMap1;
