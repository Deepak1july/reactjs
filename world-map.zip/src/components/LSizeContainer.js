import "./LSizeContainer.css";

const LSizeContainer = () => {
  return (
    <div className="widget-l-size-timeline-cha">
      <div className="info2">
        <div className="value10">
          <div className="value11">
            <div className="title14">Sales Figures</div>
            <div className="value12">$10,430</div>
          </div>
        </div>
      </div>
      <div className="graph5">
        <div className="chart1">
          <div className="column12" />
          <div className="column13" />
          <div className="column14" />
          <div className="column15" />
          <div className="column16" />
          <div className="column17" />
          <div className="column16" />
          <div className="column19" />
          <div className="column20" />
          <div className="column15" />
          <div className="column15" />
          <div className="column19" />
          <div className="column15" />
          <div className="column25" />
          <div className="column26" />
          <div className="column27" />
          <div className="column28" />
          <div className="column26" />
          <div className="column30" />
          <div className="column31" />
          <div className="column32" />
          <div className="column33" />
          <div className="column34" />
          <div className="column35" />
          <div className="column36" />
          <div className="column30" />
          <div className="column38" />
          <div className="column38" />
          <div className="column40" />
          <div className="column38" />
          <div className="column28" />
          <div className="column43" />
          <div className="column26" />
          <div className="column26" />
          <div className="column28" />
          <div className="column26" />
          <div className="column25" />
          <div className="column26" />
          <div className="column27" />
          <div className="column28" />
          <div className="column26" />
          <div className="column26" />
          <div className="column54" />
          <div className="column43" />
          <div className="column27" />
          <div className="column27" />
          <div className="column12" />
          <div className="column13" />
          <div className="column14" />
          <div className="column15" />
          <div className="column62" />
          <div className="column62" />
          <div className="column64" />
          <div className="column62" />
          <div className="column66" />
          <div className="column67" />
          <div className="column27" />
          <div className="column27" />
          <div className="column66" />
          <div className="column27" />
          <div className="column72" />
          <div className="column27" />
          <div className="column25" />
          <div className="column66" />
          <div className="column66" />
          <div className="column66" />
          <div className="column66" />
          <div className="column27" />
          <div className="column80" />
          <div className="column80" />
          <div className="column82" />
          <div className="column83" />
        </div>
        <div className="line">
          <div className="bg5" />
          <div className="cian" />
          <div className="yellow" />
        </div>
      </div>
    </div>
  );
};

export default LSizeContainer;
